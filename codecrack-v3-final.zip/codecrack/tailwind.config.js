/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        // Inter for all UI text — highly legible at small sizes
        sans:    ['Inter', 'system-ui', 'sans-serif'],
        // JetBrains Mono for code blocks, badges, monospace values
        mono:    ['JetBrains Mono', 'Fira Code', 'monospace'],
        display: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        bg: {
          base: '#070b14',
          card: '#0d1526',
          hover: '#111e35',
          border: '#1a2840',
        },
        brand: {
          cyan: '#00d4ff',
          blue: '#3b82f6',
          purple: '#8b5cf6',
          green: '#10b981',
          yellow: '#f59e0b',
          red: '#ef4444',
        }
      },
      backgroundImage: {
        'gradient-brand': 'linear-gradient(135deg, #00d4ff, #3b82f6, #8b5cf6)',
        'gradient-card': 'linear-gradient(145deg, #0d1526, #111e35)',
        'gradient-glow': 'radial-gradient(ellipse at top, rgba(0,212,255,0.08) 0%, transparent 60%)',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-slow': 'pulse 4s ease-in-out infinite',
        'slide-in': 'slideIn 0.4s ease forwards',
        'fade-up': 'fadeUp 0.5s ease forwards',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        slideIn: {
          from: { opacity: '0', transform: 'translateX(-20px)' },
          to: { opacity: '1', transform: 'translateX(0)' },
        },
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(16px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
      boxShadow: {
        'glow-cyan': '0 0 20px rgba(0, 212, 255, 0.15)',
        'glow-blue': '0 0 20px rgba(59, 130, 246, 0.2)',
        'card': '0 4px 24px rgba(0,0,0,0.4)',
      }
    },
  },
  plugins: [],
}
