// App.jsx — Root component with routing setup
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { getUser, getCurrentGmail } from './utils/localStorage.js'

import Landing from './pages/Landing.jsx'
import Dashboard from './pages/Dashboard.jsx'
import DailyChallenge from './pages/DailyChallenge.jsx'
import DSASheet from './pages/DSASheet.jsx'
import LearningHub from './pages/LearningHub.jsx'
import TopicPage from './pages/TopicPage.jsx'
import Profile from './pages/Profile.jsx'
import Login from './pages/Login.jsx'
import Layout from './components/Layout.jsx'

// Protected route wrapper — redirects to login if not logged in
function ProtectedRoute({ children }) {
  const gmail = getCurrentGmail()
  const user = gmail ? getUser(gmail) : null
  if (!user) return <Navigate to="/login" replace />
  return children
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />

        {/* Protected routes wrapped in Layout (sidebar + navbar) */}
        <Route path="/app" element={
          <ProtectedRoute><Layout /></ProtectedRoute>
        }>
          <Route index element={<Navigate to="/app/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="challenge" element={<DailyChallenge />} />
          <Route path="dsa-sheet" element={<DSASheet />} />
          <Route path="learn" element={<LearningHub />} />
          <Route path="learn/:subjectId/:topicId" element={<TopicPage />} />
          <Route path="profile" element={<Profile />} />
        </Route>

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
