// components/ProgressChart.jsx — Weekly activity + difficulty distribution charts
import { Bar, Doughnut } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, BarElement,
  Title, Tooltip, Legend,
  ArcElement
} from 'chart.js'

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement)

const CHART_DEFAULTS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { display: false } },
}

// Weekly activity bar chart
export function WeeklyChart({ data }) {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
  const today = new Date().getDay()

  // Highlight today's bar
  const bgColors = days.map((_, i) =>
    i === today
      ? 'rgba(0,212,255,0.8)'
      : 'rgba(0,212,255,0.2)'
  )
  const borderColors = days.map((_, i) =>
    i === today ? '#00d4ff' : 'rgba(0,212,255,0.4)'
  )

  const chartData = {
    labels: days,
    datasets: [{
      data: data || [0, 0, 0, 0, 0, 0, 0],
      backgroundColor: bgColors,
      borderColor: borderColors,
      borderWidth: 1,
      borderRadius: 6,
    }],
  }

  const options = {
    ...CHART_DEFAULTS,
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#64748b', font: { size: 11, family: 'Outfit' } },
      },
      y: {
        grid: { color: 'rgba(30,40,64,0.8)' },
        ticks: { color: '#64748b', stepSize: 1, font: { size: 11 } },
        beginAtZero: true,
      },
    },
    plugins: {
      tooltip: {
        backgroundColor: '#0d1526',
        borderColor: '#1a2840',
        borderWidth: 1,
        titleColor: '#e2e8f0',
        bodyColor: '#94a3b8',
        padding: 8,
        callbacks: {
          label: (ctx) => ` ${ctx.raw} problem${ctx.raw !== 1 ? 's' : ''} solved`,
        },
      },
    },
  }

  return (
    <div className="h-32">
      <Bar data={chartData} options={options} />
    </div>
  )
}

// Difficulty distribution doughnut chart
export function DifficultyChart({ easy = 0, medium = 0, hard = 0 }) {
  const total = easy + medium + hard
  const isEmpty = total === 0

  const chartData = {
    labels: ['Easy', 'Medium', 'Hard'],
    datasets: [{
      data: isEmpty ? [1, 1, 1] : [easy, medium, hard],
      backgroundColor: isEmpty
        ? ['rgba(30,40,64,0.5)', 'rgba(30,40,64,0.5)', 'rgba(30,40,64,0.5)']
        : ['rgba(16,185,129,0.7)', 'rgba(245,158,11,0.7)', 'rgba(239,68,68,0.7)'],
      borderColor: isEmpty
        ? ['#1a2840', '#1a2840', '#1a2840']
        : ['#10b981', '#f59e0b', '#ef4444'],
      borderWidth: 1.5,
    }],
  }

  const options = {
    ...CHART_DEFAULTS,
    cutout: '65%',
    plugins: {
      legend: {
        display: true,
        position: 'right',
        labels: { color: '#94a3b8', font: { size: 11, family: 'Outfit' }, boxWidth: 10, padding: 8 },
      },
      tooltip: {
        enabled: !isEmpty,
        backgroundColor: '#0d1526',
        borderColor: '#1a2840',
        borderWidth: 1,
        titleColor: '#e2e8f0',
        bodyColor: '#94a3b8',
      },
    },
  }

  return (
    <div className="h-36 relative">
      <Doughnut data={chartData} options={options} />
      {/* Center label */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none" style={{ right: '30%' }}>
        <div className="text-center">
          <div className="text-lg font-bold text-white">{total}</div>
          <div className="text-xs text-slate-500">solved</div>
        </div>
      </div>
    </div>
  )
}
