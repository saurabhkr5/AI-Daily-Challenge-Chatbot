// components/Layout.jsx — Main app shell with sidebar and top bar
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { getUser, logout } from '../utils/localStorage.js'
import Chatbot from './Chatbot.jsx'

// Navigation items config
const NAV_ITEMS = [
  { to: '/app/dashboard', icon: '⚡', label: 'Dashboard' },
  { to: '/app/challenge', icon: '🎯', label: 'Daily Challenge' },
  { to: '/app/dsa-sheet', icon: '📋', label: 'DSA Sheet' },
  { to: '/app/learn', icon: '📚', label: 'Learning Hub' },
  { to: '/app/profile', icon: '👤', label: 'Profile' },
]

function Layout() {
  const user = getUser()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  function handleLogout() {
    logout()
    navigate('/')
  }

  return (
    <div className="flex h-screen bg-bg-base overflow-hidden">
      {/* ── Sidebar ── */}
      <aside className={`${sidebarOpen ? 'w-60' : 'w-16'} flex-shrink-0 bg-bg-card border-r border-bg-border flex flex-col transition-all duration-300`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-bg-border">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #00d4ff, #3b82f6)' }}>
            CC
          </div>
          {sidebarOpen && (
            <div>
              <div className="text-sm font-bold text-white leading-tight">CodeCrack</div>
              <div className="text-xs text-slate-500">AI Practice Platform</div>
            </div>
          )}
        </div>

        {/* Nav items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map(({ to, icon, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `nav-item ${isActive ? 'active' : ''} ${!sidebarOpen ? 'justify-center' : ''}`
              }
            >
              <span className="text-base flex-shrink-0">{icon}</span>
              {sidebarOpen && <span className="text-sm">{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User section at bottom */}
        <div className="p-3 border-t border-bg-border">
          {sidebarOpen ? (
            <div className="flex items-center gap-3 px-2 py-2 rounded-lg">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #00d4ff, #8b5cf6)' }}>
                {user?.username?.[0]?.toUpperCase() || '?'}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold text-white truncate">{user?.username}</div>
                <div className="text-xs text-slate-500">🔥 {user?.streak || 0} day streak</div>
              </div>
              <button onClick={handleLogout} className="text-slate-500 hover:text-red-400 text-xs transition-colors" title="Logout">⏏</button>
            </div>
          ) : (
            <button onClick={handleLogout} className="w-full flex justify-center p-2 text-slate-500 hover:text-red-400 transition-colors text-sm" title="Logout">⏏</button>
          )}
        </div>
      </aside>

      {/* ── Main content area ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-14 bg-bg-card border-b border-bg-border flex items-center justify-between px-6 flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-slate-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-bg-hover"
          >
            {sidebarOpen ? '◀' : '▶'}
          </button>
          <div className="flex items-center gap-4">
            <div className="text-xs text-slate-500 font-mono">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </div>
            <div className="h-4 w-px bg-bg-border" />
            <div className="text-xs text-slate-400">
              🔥 <span className="text-white font-semibold">{user?.streak || 0}</span> streak
            </div>
            <div className="text-xs text-slate-400">
              ⭐ <span className="text-white font-semibold">{user?.totalSolved || 0}</span> solved
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto bg-mesh">
          <Outlet />
        </main>
      </div>

      {/* Floating AI Chatbot */}
      <Chatbot />
    </div>
  )
}

export default Layout
