// components/Chatbot.jsx — Floating Gemini AI assistant with localStorage caching
import { useState, useRef, useEffect } from 'react'
import { getAICache, setAICache } from '../utils/localStorage.js'
import { fetchAIHint } from '../utils/mockAPI.js'

export default function Chatbot() {
  const [isOpen, setIsOpen]     = useState(false)
  const [messages, setMessages] = useState([{
    role: 'bot',
    text: "👋 Hi! I'm your AI coding assistant powered by Gemini.\n\nAsk me anything:\n• 💡 Hint for [problem name]\n• 🗺️ Approach for [problem]\n• ⏱️ Complexity of [problem]\n• 🤔 Explain [any concept]",
  }])
  const [input, setInput]       = useState('')
  const [loading, setLoading]   = useState(false)
  const [currentProblem, setCurrentProblem] = useState('')
  const messagesEndRef = useRef(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  function parseMessage(msg) {
    const lower = msg.toLowerCase()
    let type = 'hint'
    if (lower.includes('approach') || lower.includes('explain') || lower.includes('how')) type = 'approach'
    if (lower.includes('complexity') || lower.includes('time') || lower.includes('space') || lower.includes('big o')) type = 'complexity'
    const match = msg.match(/for\s+["']?([^"']+?)["']?\s*(?:problem)?$/i)
    const problemTitle = match?.[1]?.trim() || currentProblem || 'this problem'
    if (problemTitle !== 'this problem') setCurrentProblem(problemTitle)
    const cacheKey = `${type}_${problemTitle.toLowerCase().replace(/\s+/g, '-')}`
    return { type, problemTitle, cacheKey }
  }

  async function sendMessage() {
    const trimmed = input.trim()
    if (!trimmed || loading) return
    setMessages(prev => [...prev, { role: 'user', text: trimmed }])
    setInput('')
    setLoading(true)

    const { type, problemTitle, cacheKey } = parseMessage(trimmed)

    try {
      // Check localStorage cache first — saves API quota
      const cached = getAICache(cacheKey)
      if (cached) {
        setMessages(prev => [...prev, {
          role: 'bot',
          text: cached.response + '\n\n_💾 from cache_',
        }])
        setLoading(false)
        return
      }

      // Call Gemini API (falls back to mock if unavailable)
      const response = await fetchAIHint(
        problemTitle.toLowerCase().replace(/\s+/g, '-'),
        problemTitle,
        type
      )

      // Save to cache so this question is never asked again
      setAICache(cacheKey, response)
      setMessages(prev => [...prev, { role: 'bot', text: response }])
    } catch (err) {
      setMessages(prev => [...prev, {
        role: 'bot',
        text: '⚠️ AI unavailable. Try: hint / approach / complexity for [problem name].',
      }])
    } finally {
      setLoading(false)
    }
  }

  const QUICK = [
    { label: '💡 Hint', msg: `Hint for ${currentProblem || 'two sum'}` },
    { label: '🗺️ Approach', msg: `Approach for ${currentProblem || 'two sum'}` },
    { label: '⏱️ Complexity', msg: `Complexity of ${currentProblem || 'two sum'}` },
  ]

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setIsOpen(v => !v)}
        title="AI Assistant"
        className="fixed bottom-6 right-6 z-50 w-13 h-13 rounded-2xl flex items-center justify-center shadow-2xl transition-all duration-300 hover:scale-110"
        style={{ background: 'linear-gradient(135deg, #00d4ff, #8b5cf6)', width: 52, height: 52 }}
      >
        <span className="text-xl">{isOpen ? '✕' : '🤖'}</span>
      </button>

      {/* Chat panel */}
      {isOpen && (
        <div className="fixed bottom-20 right-6 z-50 w-80 flex flex-col rounded-2xl shadow-2xl border border-bg-border overflow-hidden"
          style={{ background: '#0d1526', maxHeight: 480 }}>

          {/* Header */}
          <div className="flex items-center gap-2.5 px-4 py-3 border-b border-bg-border"
            style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.1), rgba(139,92,246,0.1))' }}>
            <div className="w-7 h-7 rounded-lg flex items-center justify-center text-sm"
              style={{ background: 'linear-gradient(135deg,#00d4ff,#8b5cf6)' }}>🤖</div>
            <div>
              <div className="text-sm font-bold text-white">Gemini AI Assistant</div>
              <div className="text-xs text-slate-500">Powered by Google Gemini</div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5" style={{ minHeight: 250, maxHeight: 300 }}>
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] text-xs rounded-xl px-3 py-2 leading-relaxed whitespace-pre-wrap ${
                  m.role === 'user'
                    ? 'text-white'
                    : 'text-slate-300 border border-bg-border'
                }`}
                  style={m.role === 'user'
                    ? { background: 'linear-gradient(135deg,#00d4ff22,#3b82f622)' }
                    : { background: '#111827' }}>
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-bg-hover border border-bg-border rounded-xl px-3 py-2 text-xs text-slate-400">
                  <span className="animate-pulse">Thinking...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick prompts */}
          <div className="flex gap-1.5 px-3 pb-2 overflow-x-auto">
            {QUICK.map(q => (
              <button key={q.label} onClick={() => { setInput(q.msg); }}
                className="text-xs px-2.5 py-1 rounded-lg border border-bg-border text-slate-400 hover:text-white hover:border-brand-cyan/40 whitespace-nowrap transition-all flex-shrink-0">
                {q.label}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="flex gap-2 p-3 pt-0">
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage()}
              placeholder="Ask about any problem..."
              className="flex-1 bg-bg-card border border-bg-border rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-brand-cyan/50"
            />
            <button onClick={sendMessage} disabled={loading || !input.trim()}
              className="w-9 h-9 rounded-xl flex items-center justify-center disabled:opacity-40 transition-all"
              style={{ background: 'linear-gradient(135deg,#00d4ff,#8b5cf6)' }}>
              <span className="text-sm">↑</span>
            </button>
          </div>
        </div>
      )}
    </>
  )
}
