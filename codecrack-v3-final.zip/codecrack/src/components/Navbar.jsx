// components/Navbar.jsx — Top navigation bar for landing/auth pages
import { Link, useNavigate } from 'react-router-dom'
import { getUser } from '../utils/localStorage.js'

function Navbar() {
  const user = getUser()
  const navigate = useNavigate()

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 border-b border-bg-border backdrop-blur-md"
      style={{ background: 'rgba(7,11,20,0.8)' }}>
      <div className="max-w-6xl mx-auto px-6 h-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
            style={{ background: 'linear-gradient(135deg, #00d4ff, #3b82f6)' }}>
            CC
          </div>
          <span className="font-bold text-white text-sm">CodeCrack</span>
        </Link>

        {/* Actions */}
        <div className="flex items-center gap-3">
          {user ? (
            <button onClick={() => navigate('/app/dashboard')} className="btn-primary text-xs">
              Go to Dashboard →
            </button>
          ) : (
            <>
              <Link to="/login" className="btn-ghost text-xs">Sign In</Link>
              <Link to="/login" className="btn-primary text-xs">Get Started</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}

export default Navbar
