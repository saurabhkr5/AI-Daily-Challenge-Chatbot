// components/ChallengeCard.jsx — Card displaying a single coding challenge
import { useState } from 'react'
import { updateUserStats, getUser } from '../utils/localStorage.js'

const DIFF_CONFIG = {
  Easy: { class: 'badge-easy', color: '#10b981', bg: 'rgba(16,185,129,0.08)' },
  Medium: { class: 'badge-medium', color: '#f59e0b', bg: 'rgba(245,158,11,0.08)' },
  Hard: { class: 'badge-hard', color: '#ef4444', bg: 'rgba(239,68,68,0.08)' },
}

function ChallengeCard({ question, onSolved }) {
  const user = getUser()
  const isSolved = user?.solvedProblems?.includes(question.id) || false
  const [solved, setSolved] = useState(isSolved)
  const config = DIFF_CONFIG[question.difficulty] || DIFF_CONFIG.Easy

  function handleMarkSolved() {
    if (solved) return
    updateUserStats(question.id, question.difficulty)
    setSolved(true)
    onSolved?.() // notify parent to refresh stats
  }

  return (
    <div className={`card relative overflow-hidden transition-all duration-300 ${solved ? 'opacity-80' : 'hover:border-slate-600 hover:-translate-y-0.5'}`}
      style={solved ? { borderColor: 'rgba(16,185,129,0.3)', background: 'rgba(16,185,129,0.04)' } : {}}>
      
      {/* Subtle difficulty glow */}
      <div className="absolute top-0 left-0 w-1 h-full rounded-l-2xl" style={{ background: config.color }} />

      <div className="pl-3">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <h3 className="font-semibold text-white text-sm leading-tight mb-1">{question.title}</h3>
            <div className="flex items-center gap-2 flex-wrap">
              <span className={config.class}>{question.difficulty}</span>
              <span className="text-xs text-slate-500 bg-bg-hover px-2 py-0.5 rounded-full border border-bg-border">
                {question.platform}
              </span>
              {question.tags?.slice(0, 2).map(tag => (
                <span key={tag} className="text-xs text-slate-500">{tag}</span>
              ))}
            </div>
          </div>
          {solved && (
            <div className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs"
              style={{ background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.3)' }}>
              ✓
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <a href={question.link} target="_blank" rel="noopener noreferrer"
            className="text-xs px-3 py-1.5 rounded-lg border border-bg-border text-slate-400 hover:text-brand-cyan hover:border-brand-cyan/30 transition-all duration-200">
            LeetCode ↗
          </a>
          {question.gfgLink && (
            <a href={question.gfgLink} target="_blank" rel="noopener noreferrer"
              className="text-xs px-3 py-1.5 rounded-lg border border-bg-border text-slate-400 hover:text-brand-green hover:border-brand-green/30 transition-all duration-200">
              GFG ↗
            </a>
          )}
          <button
            onClick={handleMarkSolved}
            disabled={solved}
            className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all duration-200 ml-auto ${
              solved
                ? 'text-brand-green border border-brand-green/30 cursor-not-allowed'
                : 'text-white hover:opacity-80'
            }`}
            style={!solved ? { background: 'linear-gradient(135deg, #00d4ff, #3b82f6)', boxShadow: '0 2px 8px rgba(0,212,255,0.2)' } : {}}
          >
            {solved ? '✓ Completed' : 'Mark Solved'}
          </button>
        </div>
      </div>
    </div>
  )
}

export default ChallengeCard
