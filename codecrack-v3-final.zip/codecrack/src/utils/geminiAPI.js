// utils/geminiAPI.js
// Gemini AI integration with automatic mock fallback.
// All AI calls (chatbot hints, daily question generation) go through this file.

const GEMINI_API_KEY = 'AIzaSyD3KFu7t8dIV74HIvAq_8hioeCLLboRoKI';
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

// ── MOCK FALLBACKS ─────────────────────────────────────────────────────────────
// Used when Gemini API is unavailable, rate-limited, or returns an error.

const MOCK_HINTS = {
  hint: {
    'two-sum': '💡 Use a hash map to store each number and its complement as you iterate. For each num, check if (target - num) exists in the map. This gives O(n) time instead of O(n²).',
    'palindrome': '💡 Two pointer approach: one from start, one from end. Skip non-alphanumeric chars. Compare lowercase values.',
    'climbing-stairs': '💡 This is Fibonacci in disguise! dp[n] = dp[n-1] + dp[n-2]. You can reach step n from step n-1 or n-2.',
    'max-subarray': "💡 Kadane's Algorithm: keep a running sum. If it drops below 0, reset it. Track the maximum seen so far.",
    'coin-change': '💡 Classic bottom-up DP. dp[i] = min coins to make amount i. For each coin, try dp[i - coin] + 1.',
    'num-islands': '💡 DFS/BFS from each unvisited land cell. Mark visited cells as water. Count how many DFS calls you make.',
    'house-robber': '💡 At each house: max(rob_this + prev_prev, skip_this). Use two variables, no array needed.',
    'three-sum': '💡 Sort the array. Fix one number, use two pointers for the other two. Skip duplicates carefully.',
    'product-arr': '💡 Two passes: left pass gives product of all left elements, right pass multiplies product of right elements.',
    default: '💡 Break the problem into smaller subproblems. Identify the pattern — greedy, DP, two pointers, or divide & conquer?',
  },
  approach: {
    'two-sum': '🗺️ Single-pass HashMap: store seen[num] = index. At each step check if target-num is in seen. O(n) time, O(n) space.',
    'max-subarray': "🗺️ Kadane's: O(n) time, O(1) space. Maintain curr_sum and max_sum. Reset curr_sum to 0 when negative.",
    default: '🗺️ Steps: 1) Identify pattern (sliding window / DP / two pointers / graph). 2) Brute force first. 3) Optimise. 4) Check edge cases.',
  },
  complexity: {
    'two-sum': '⏱️ Brute: O(n²) time O(1) space. Optimal: O(n) time O(n) space (hash map).',
    'max-subarray': "⏱️ Kadane's: O(n) time, O(1) space.",
    'num-islands': '⏱️ O(m×n) time and space — visit each cell once.',
    default: '⏱️ Count loops (each = factor of n). Nested loops = O(n²). Recursive halving = O(log n). Recursion with memoization = O(states).',
  },
};

const MOCK_DAILY_QUESTIONS = {
  easy: [
    { id: 'two-sum', title: 'Two Sum', difficulty: 'Easy', platform: 'LeetCode', link: 'https://leetcode.com/problems/two-sum/', gfgLink: 'https://www.geeksforgeeks.org/given-an-array-a-and-a-number-x-check-for-pair-in-a-with-sum-as-x/', tags: ['Array', 'Hash Map'], companies: ['Google', 'Amazon', 'Meta'] },
    { id: 'palindrome', title: 'Valid Palindrome', difficulty: 'Easy', platform: 'LeetCode', link: 'https://leetcode.com/problems/valid-palindrome/', gfgLink: 'https://www.geeksforgeeks.org/c-program-check-given-string-palindrome/', tags: ['String', 'Two Pointers'], companies: ['Apple', 'Microsoft'] },
    { id: 'climbing-stairs', title: 'Climbing Stairs', difficulty: 'Easy', platform: 'LeetCode', link: 'https://leetcode.com/problems/climbing-stairs/', gfgLink: 'https://www.geeksforgeeks.org/count-ways-reach-nth-stair/', tags: ['DP', 'Math'], companies: ['Amazon', 'Adobe'] },
    { id: 'contains-dup', title: 'Contains Duplicate', difficulty: 'Easy', platform: 'LeetCode', link: 'https://leetcode.com/problems/contains-duplicate/', gfgLink: 'https://www.geeksforgeeks.org/check-if-array-contains-duplicates/', tags: ['Array', 'Hash Set'], companies: ['Apple', 'Google'] },
    { id: 'best-time-stocks', title: 'Best Time to Buy/Sell Stock', difficulty: 'Easy', platform: 'LeetCode', link: 'https://leetcode.com/problems/best-time-to-buy-and-sell-stock/', gfgLink: 'https://www.geeksforgeeks.org/stock-buy-sell/', tags: ['Array', 'Greedy'], companies: ['Amazon', 'Goldman Sachs'] },
  ],
  medium: [
    { id: 'longest-substring', title: 'Longest Substring Without Repeating', difficulty: 'Medium', platform: 'LeetCode', link: 'https://leetcode.com/problems/longest-substring-without-repeating-characters/', gfgLink: 'https://www.geeksforgeeks.org/length-of-the-longest-substring-without-repeating-characters/', tags: ['Sliding Window'], companies: ['Amazon', 'Google', 'Bloomberg'] },
    { id: 'max-subarray', title: "Maximum Subarray (Kadane's)", difficulty: 'Medium', platform: 'LeetCode', link: 'https://leetcode.com/problems/maximum-subarray/', gfgLink: 'https://www.geeksforgeeks.org/largest-sum-contiguous-subarray/', tags: ['Array', 'DP'], companies: ['Microsoft', 'Amazon'] },
    { id: 'num-islands', title: 'Number of Islands', difficulty: 'Medium', platform: 'LeetCode', link: 'https://leetcode.com/problems/number-of-islands/', gfgLink: 'https://www.geeksforgeeks.org/find-number-of-islands/', tags: ['DFS', 'BFS'], companies: ['Google', 'Amazon', 'Bloomberg'] },
    { id: 'three-sum', title: '3Sum', difficulty: 'Medium', platform: 'LeetCode', link: 'https://leetcode.com/problems/3sum/', gfgLink: 'https://www.geeksforgeeks.org/find-a-triplet-that-sum-to-a-given-value/', tags: ['Array', 'Two Pointers'], companies: ['Google', 'Meta', 'Adobe'] },
    { id: 'coin-change', title: 'Coin Change', difficulty: 'Medium', platform: 'LeetCode', link: 'https://leetcode.com/problems/coin-change/', gfgLink: 'https://www.geeksforgeeks.org/coin-change-dp-7/', tags: ['DP'], companies: ['Amazon', 'Microsoft'] },
    { id: 'merge-intervals', title: 'Merge Intervals', difficulty: 'Medium', platform: 'LeetCode', link: 'https://leetcode.com/problems/merge-intervals/', gfgLink: 'https://www.geeksforgeeks.org/merging-intervals/', tags: ['Array', 'Sorting'], companies: ['Google', 'Facebook', 'Oracle'] },
  ],
  hard: [
    { id: 'median-arrays', title: 'Median of Two Sorted Arrays', difficulty: 'Hard', platform: 'LeetCode', link: 'https://leetcode.com/problems/median-of-two-sorted-arrays/', gfgLink: 'https://www.geeksforgeeks.org/median-of-two-sorted-arrays/', tags: ['Array', 'Binary Search'], companies: ['Google', 'Amazon'] },
    { id: 'trapping-rain', title: 'Trapping Rain Water', difficulty: 'Hard', platform: 'LeetCode', link: 'https://leetcode.com/problems/trapping-rain-water/', gfgLink: 'https://www.geeksforgeeks.org/trapping-rain-water/', tags: ['Array', 'Stack'], companies: ['Amazon', 'Microsoft', 'Goldman Sachs'] },
    { id: 'serialize-tree', title: 'Serialize & Deserialize Binary Tree', difficulty: 'Hard', platform: 'LeetCode', link: 'https://leetcode.com/problems/serialize-and-deserialize-binary-tree/', gfgLink: 'https://www.geeksforgeeks.org/serialize-deserialize-binary-tree/', tags: ['Tree', 'DFS'], companies: ['Meta', 'Google'] },
  ],
};

// ── HELPER: Call Gemini API ────────────────────────────────────────────────────
async function callGemini(prompt, maxTokens = 512) {
  const res = await fetch(GEMINI_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { maxOutputTokens: maxTokens, temperature: 0.7 },
    }),
  });
  if (!res.ok) throw new Error(`Gemini HTTP ${res.status}`);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Empty Gemini response');
  return text.trim();
}

// ── AI HINT (with mock fallback) ──────────────────────────────────────────────
/**
 * Get an AI hint/approach/complexity for a coding problem.
 * Tries Gemini first; on any error falls back to mock hints.
 *
 * @param {string} questionId    - e.g. "two-sum"
 * @param {string} questionTitle - human-readable title
 * @param {string} type          - "hint" | "approach" | "complexity"
 */
export async function getAIHint(questionId, questionTitle, type = 'hint') {
  const prompts = {
    hint: `You are a coding interview coach. Give a concise, beginner-friendly hint (max 3 sentences) for the LeetCode problem "${questionTitle}". Don't give away the full solution. Start with 💡`,
    approach: `You are a coding interview coach. Explain the optimal approach for "${questionTitle}" in 3-4 sentences. Mention the data structure used and time/space complexity. Start with 🗺️`,
    complexity: `You are a coding interview coach. State the brute-force and optimal time/space complexity for "${questionTitle}" and explain why in 2-3 sentences. Start with ⏱️`,
  };
  try {
    const result = await callGemini(prompts[type] || prompts.hint, 200);
    return result;
  } catch (err) {
    console.warn('[Gemini API failed, using mock]', err.message);
    // Fallback to mock
    const pool = MOCK_HINTS[type] || MOCK_HINTS.hint;
    return pool[questionId] || pool.default;
  }
}

// ── DAILY QUESTION GENERATION (with mock fallback) ────────────────────────────
/**
 * Ask Gemini to pick 3 LeetCode problems (Easy/Medium/Hard) for today.
 * Returns array of 3 question objects.
 * Falls back to picking randomly from MOCK_DAILY_QUESTIONS.
 *
 * Questions are saved to localStorage once per day — this function is only
 * called when no cached questions exist for today.
 */
export async function getAIDailyQuestions() {
  const prompt = `You are a coding interview question curator. Pick exactly 3 LeetCode problems for today's practice — one Easy, one Medium, one Hard. Choose popular problems asked at top tech companies (Google, Amazon, Meta, Microsoft).

Return ONLY a JSON array (no markdown, no explanation) with exactly 3 objects. Each object must have these exact fields:
{
  "id": "kebab-case-id",
  "title": "Problem Title",
  "difficulty": "Easy" | "Medium" | "Hard",
  "platform": "LeetCode",
  "link": "https://leetcode.com/problems/...",
  "gfgLink": "https://www.geeksforgeeks.org/...",
  "tags": ["tag1", "tag2"],
  "companies": ["Company1", "Company2"]
}

Vary the topics — don't repeat tags from: Arrays, Strings, Trees, DP, Graph.`;

  try {
    const raw = await callGemini(prompt, 600);
    // Strip any accidental markdown backticks
    const clean = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);
    if (Array.isArray(parsed) && parsed.length === 3) return parsed;
    throw new Error('Invalid format from Gemini');
  } catch (err) {
    console.warn('[Gemini daily questions failed, using mock]', err.message);
    return _mockDailyPick();
  }
}

// Pick one random from each difficulty pool
function _mockDailyPick() {
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];
  return [
    pick(MOCK_DAILY_QUESTIONS.easy),
    pick(MOCK_DAILY_QUESTIONS.medium),
    pick(MOCK_DAILY_QUESTIONS.hard),
  ];
}
