// utils/localStorage.js
// All localStorage operations. Supports per-user data keyed by gmail.

// ── KEY HELPERS ───────────────────────────────────────────────────────────────
// User-specific keys are prefixed with the gmail so multiple users can share
// the same browser without overwriting each other's progress.

function userKey(gmail, suffix) {
  // e.g. "cc_user_alice@gmail.com_dsa_progress"
  const safe = gmail.replace(/[^a-zA-Z0-9@._-]/g, '_');
  return `cc_user_${safe}_${suffix}`;
}

// ── CURRENT SESSION ────────────────────────────────────────────────────────────
// Which gmail is currently logged in (lightweight session)
const SESSION_KEY = 'cc_current_gmail';

export function getCurrentGmail() {
  return localStorage.getItem(SESSION_KEY) || null;
}

export function setCurrentGmail(gmail) {
  localStorage.setItem(SESSION_KEY, gmail);
}

export function clearCurrentGmail() {
  localStorage.removeItem(SESSION_KEY);
}

// ── USER PROFILE ──────────────────────────────────────────────────────────────

export function getUser(gmail) {
  const g = gmail || getCurrentGmail();
  if (!g) return null;
  try {
    const raw = localStorage.getItem(userKey(g, 'profile'));
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function saveUser(user) {
  if (!user?.gmail) return;
  localStorage.setItem(userKey(user.gmail, 'profile'), JSON.stringify(user));
}

/**
 * Create or return existing user profile for this gmail.
 * Existing progress is NEVER overwritten.
 */
export function createUser(username, gmail) {
  const existing = getUser(gmail);
  if (existing) {
    // Already exists — update name if changed, keep all progress
    existing.username = username;
    saveUser(existing);
    setCurrentGmail(gmail);
    return existing;
  }
  const user = {
    username,
    gmail,
    avatar: username[0].toUpperCase(),
    joinedDate: new Date().toISOString().split('T')[0],
    solvedProblems: [],
    streak: 0,
    totalSolved: 0,
    lastActiveDate: null,
    weeklyActivity: [0, 0, 0, 0, 0, 0, 0], // Sun→Sat
    achievements: [],
  };
  saveUser(user);
  setCurrentGmail(gmail);
  return user;
}

export function updateUserStats(problemId) {
  const gmail = getCurrentGmail();
  const user = getUser(gmail);
  if (!user) return;

  const today = new Date().toISOString().split('T')[0];

  if (!user.solvedProblems.includes(problemId)) {
    user.solvedProblems.push(problemId);
    user.totalSolved += 1;

    if (user.lastActiveDate === today) {
      // already solved today — streak unchanged
    } else if (isYesterday(user.lastActiveDate)) {
      user.streak += 1;
    } else {
      user.streak = 1;
    }
    user.lastActiveDate = today;

    const dayIndex = new Date().getDay();
    user.weeklyActivity[dayIndex] = (user.weeklyActivity[dayIndex] || 0) + 1;

    checkAndAddAchievements(user);
    saveUser(user);
  }
  return user;
}

function isYesterday(dateStr) {
  if (!dateStr) return false;
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return dateStr === yesterday.toISOString().split('T')[0];
}

function checkAndAddAchievements(user) {
  const a = user.achievements || [];
  const add = (id, title, icon) => {
    if (!a.find(x => x.id === id))
      a.push({ id, title, icon, date: new Date().toISOString().split('T')[0] });
  };
  if (user.totalSolved >= 1)  add('first_solve', 'First Problem Solved', '🎯');
  if (user.totalSolved >= 10) add('ten_solved', '10 Problems Solved', '🔥');
  if (user.totalSolved >= 25) add('twenty_five', '25 Problems Solved', '⚡');
  if (user.totalSolved >= 50) add('fifty_solved', '50 Problems Solved', '💎');
  if (user.streak >= 3)  add('streak_3', '3-Day Streak', '🌟');
  if (user.streak >= 7)  add('streak_7', 'Week Warrior', '🏆');
  if (user.streak >= 30) add('streak_30', '30-Day Legend', '👑');
  user.achievements = a;
}

export function logout() {
  clearCurrentGmail();
  // NOTE: User profile data stays in localStorage — next login restores it
}

// ── AI CACHE (per-user, per-question) ─────────────────────────────────────────
// Key: cc_user_<gmail>_ai_<cacheKey>

export function getAICache(cacheKey) {
  const gmail = getCurrentGmail();
  if (!gmail) return null;
  try {
    const raw = localStorage.getItem(userKey(gmail, `ai_${cacheKey}`));
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function setAICache(cacheKey, response) {
  const gmail = getCurrentGmail();
  if (!gmail) return;
  try {
    localStorage.setItem(
      userKey(gmail, `ai_${cacheKey}`),
      JSON.stringify({ response, cachedAt: Date.now() })
    );
  } catch {}
}

// ── DAILY QUESTIONS CACHE (shared, not per-user — same questions for all) ─────
// Key: cc_daily_YYYY-MM-DD

export function getDailyQuestionsCache(date) {
  try {
    const raw = localStorage.getItem(`cc_daily_${date}`);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function setDailyQuestionsCache(date, questions) {
  try {
    localStorage.setItem(`cc_daily_${date}`, JSON.stringify(questions));
  } catch {}
}

export function clearDailyQuestionsCache(date) {
  localStorage.removeItem(`cc_daily_${date}`);
}

// ── DSA PROGRESS (per-user) ────────────────────────────────────────────────────

export function getDSAProgress() {
  const gmail = getCurrentGmail();
  if (!gmail) return {};
  try {
    const raw = localStorage.getItem(userKey(gmail, 'dsa'));
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

export function toggleDSASolved(questionId) {
  const gmail = getCurrentGmail();
  if (!gmail) return {};
  const progress = getDSAProgress();
  if (progress[questionId]) {
    delete progress[questionId];
  } else {
    progress[questionId] = { solvedAt: Date.now() };
  }
  localStorage.setItem(userKey(gmail, 'dsa'), JSON.stringify(progress));
  return progress;
}

// ── LEARNING PROGRESS (per-user) ──────────────────────────────────────────────

export function getLearningProgress() {
  const gmail = getCurrentGmail();
  if (!gmail) return {};
  try {
    const raw = localStorage.getItem(userKey(gmail, 'learning'));
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

export function markTopicRead(topicId) {
  const gmail = getCurrentGmail();
  if (!gmail) return;
  const prog = getLearningProgress();
  prog[topicId] = { readAt: Date.now() };
  localStorage.setItem(userKey(gmail, 'learning'), JSON.stringify(prog));
}
