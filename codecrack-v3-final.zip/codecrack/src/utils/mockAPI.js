// utils/mockAPI.js
// Thin wrapper around geminiAPI.js that manages localStorage caching.
// Components import from here — never directly from geminiAPI.js.

import {
  getDailyQuestionsCache,
  setDailyQuestionsCache,
  clearDailyQuestionsCache,
} from './localStorage.js';
import { getAIDailyQuestions, getAIHint } from './geminiAPI.js';

// ── DAILY CHALLENGES ──────────────────────────────────────────────────────────
// Fetched ONCE per day and stored in localStorage: daily_questions_YYYY-MM-DD
// On subsequent loads that day → return cache instantly, no API call.

export async function fetchDailyChallenges(forceRefresh = false) {
  const today = new Date().toISOString().split('T')[0];

  if (!forceRefresh) {
    const cached = getDailyQuestionsCache(today);
    if (cached) return { questions: cached, fromCache: true };
  }

  // Call Gemini (falls back to mock inside geminiAPI.js)
  const questions = await getAIDailyQuestions();
  setDailyQuestionsCache(today, questions);
  return { questions, fromCache: false };
}

export async function refreshDailyQuestions() {
  const today = new Date().toISOString().split('T')[0];
  clearDailyQuestionsCache(today);
  return fetchDailyChallenges(true);
}

// Re-export hint function so Chatbot can import from here
export { getAIHint as fetchAIHint };
