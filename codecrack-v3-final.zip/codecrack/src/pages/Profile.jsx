// pages/Profile.jsx — User profile with stats, achievements, and account management
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getUser, logout, getDSAProgress, getLearningProgress } from '../utils/localStorage.js'
import dsaQuestions from '../data/dsaQuestions.json'

const ACHIEVEMENT_DEFS = [
  { id: 'first_solve',    icon: '🎯', title: 'First Problem Solved',  desc: 'Solved your very first problem' },
  { id: 'ten_solved',     icon: '🔥', title: '10 Problems Solved',    desc: 'On your way to mastery' },
  { id: 'twenty_five',    icon: '⚡', title: '25 Problems Solved',    desc: 'Quarter century of problems' },
  { id: 'streak_3',       icon: '🌟', title: '3-Day Streak',          desc: 'Consistent daily practice' },
  { id: 'streak_7',       icon: '🏆', title: 'Week Warrior',          desc: '7 days in a row!' },
]

export default function Profile() {
  const [user, setUser] = useState(getUser())
  const navigate = useNavigate()
  const progress = getDSAProgress()
  const dsaSolved = Object.keys(progress).length

  // Count problems solved across difficulty levels
  const easyIds = ['two-sum','palindrome','fizzbuzz','reverse-string','climbing-stairs','max-depth-tree','contains-duplicate','best-time-stocks','merge-sorted','single-number']
  const hardIds = ['median-arrays','trapping-rain','word-break-ii','serialize-tree','sliding-window-max']
  const easy = user?.solvedProblems?.filter(id => easyIds.includes(id)).length || 0
  const hard = user?.solvedProblems?.filter(id => hardIds.includes(id)).length || 0
  const medium = Math.max(0, (user?.totalSolved || 0) - easy - hard)

  // Unlocked achievements
  const unlockedIds = new Set(user?.achievements?.map(a => a.id) || [])

  function handleLogout() {
    logout()
    navigate('/')
  }

  // Days since joined
  function daysSince(dateStr) {
    if (!dateStr) return 0
    const diff = Date.now() - new Date(dateStr).getTime()
    return Math.max(1, Math.floor(diff / (1000 * 60 * 60 * 24)))
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      {/* Profile card */}
      <div className="card mb-5" style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.04), rgba(139,92,246,0.04))' }}>
        <div className="flex items-start gap-5">
          {/* Avatar */}
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #00d4ff, #8b5cf6)', boxShadow: '0 0 20px rgba(0,212,255,0.3)' }}>
            {user?.username?.[0]?.toUpperCase()}
          </div>
          {/* Info */}
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-black text-white">{user?.username}</h1>
            <div className="text-xs text-slate-500 mt-0.5">
              Member for {daysSince(user?.joinedDate)} days • Joined {user?.joinedDate}
            </div>
            <div className="flex items-center gap-3 mt-2 flex-wrap">
              <span className="text-xs px-2.5 py-1 rounded-full bg-brand-cyan/10 text-brand-cyan border border-brand-cyan/20">
                🔥 {user?.streak || 0} day streak
              </span>
              <span className="text-xs px-2.5 py-1 rounded-full bg-brand-green/10 text-brand-green border border-brand-green/20">
                ✅ {user?.totalSolved || 0} solved
              </span>
              {user?.achievements?.length > 0 && (
                <span className="text-xs px-2.5 py-1 rounded-full bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                  🏅 {user.achievements.length} badges
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Total Solved', value: user?.totalSolved || 0, color: '#00d4ff', icon: '✅' },
          { label: 'Day Streak', value: user?.streak || 0, color: '#f59e0b', icon: '🔥' },
          { label: 'DSA Sheet', value: `${dsaSolved}/75`, color: '#8b5cf6', icon: '📋' },
          { label: 'Days Active', value: daysSince(user?.joinedDate), color: '#10b981', icon: '📅' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ '--accent-color': s.color }}>
            <div className="text-xl mb-1.5">{s.icon}</div>
            <div className="text-xl font-black text-white">{s.value}</div>
            <div className="text-xs text-slate-500">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Difficulty breakdown */}
      <div className="card mb-5">
        <h3 className="text-sm font-bold text-white mb-4">Problems by Difficulty</h3>
        <div className="space-y-3">
          {[
            { label: 'Easy', count: easy, total: 10, color: '#10b981', barColor: 'bg-brand-green' },
            { label: 'Medium', count: medium, total: 10, color: '#f59e0b', barColor: 'bg-brand-yellow' },
            { label: 'Hard', count: hard, total: 5, color: '#ef4444', barColor: 'bg-brand-red' },
          ].map(d => (
            <div key={d.label}>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span style={{ color: d.color }} className="font-semibold">{d.label}</span>
                <span className="text-slate-500">{d.count} / {d.total}</span>
              </div>
              <div className="progress-bar">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${Math.min(100, (d.count / d.total) * 100)}%`,
                    background: d.color
                  }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="card mb-5">
        <h3 className="text-sm font-bold text-white mb-4">Achievements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {ACHIEVEMENT_DEFS.map(ach => {
            const unlocked = unlockedIds.has(ach.id)
            const earnedDate = user?.achievements?.find(a => a.id === ach.id)?.date
            return (
              <div key={ach.id}
                className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                  unlocked
                    ? 'border-yellow-500/20 bg-yellow-500/4'
                    : 'border-bg-border opacity-40 grayscale'
                }`}>
                <span className="text-2xl flex-shrink-0">{ach.icon}</span>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">{ach.title}</div>
                  <div className="text-xs text-slate-500">{ach.desc}</div>
                  {unlocked && earnedDate && (
                    <div className="text-xs text-yellow-500/70 mt-0.5">Earned {earnedDate}</div>
                  )}
                </div>
                {unlocked && (
                  <div className="ml-auto flex-shrink-0 w-5 h-5 rounded-full bg-yellow-500/15 border border-yellow-500/30 flex items-center justify-center text-xs text-yellow-400">
                    ✓
                  </div>
                )}
              </div>
            )
          })}
        </div>
        {unlockedIds.size === 0 && (
          <p className="text-center text-xs text-slate-600 mt-2">Solve problems to unlock achievements!</p>
        )}
      </div>

      {/* Danger zone */}
      <div className="card border-red-900/20">
        <h3 className="text-sm font-bold text-red-400 mb-3">Account</h3>
        <p className="text-xs text-slate-500 mb-3">
          Logging out will clear all local data. This action cannot be undone.
        </p>
        <button onClick={handleLogout} className="btn-danger text-xs px-4 py-2 rounded-lg border border-red-500/20 text-red-400 hover:bg-red-500/10 transition-colors">
          Sign Out & Clear Data
        </button>
      </div>
    </div>
  )
}
