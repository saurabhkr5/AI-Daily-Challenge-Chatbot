// pages/Landing.jsx — Public landing page
import { useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { getUser } from '../utils/localStorage.js'
import Navbar from '../components/Navbar.jsx'

const FEATURES = [
  { icon: '🎯', title: 'Daily Challenges', desc: '3 curated problems (Easy/Medium/Hard) refreshed every day' },
  { icon: '📋', title: 'DSA Sheet', desc: 'Top 50 problems covering all essential data structures' },
  { icon: '📚', title: 'Learning Hub', desc: '8 CS subjects with deep explanations and interview questions' },
  { icon: '🤖', title: 'AI Assistant', desc: 'Get hints and explanations powered by Gemini AI' },
  { icon: '📊', title: 'Progress Tracking', desc: 'Visual charts tracking your weekly activity and growth' },
  { icon: '🔥', title: 'Streak System', desc: 'Stay consistent with daily streaks and achievements' },
]

const STATS = [
  { label: 'Problems', value: '50+' },
  { label: 'CS Topics', value: '30+' },
  { label: 'Daily Challenges', value: '3/day' },
  { label: 'AI-Powered', value: '100%' },
]

export default function Landing() {
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    // Redirect if already logged in
    if (getUser()) navigate('/app/dashboard')
    setTimeout(() => setVisible(true), 100)
  }, [navigate])

  return (
    <div className="min-h-screen bg-bg-base">
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-20 px-6 text-center bg-mesh relative overflow-hidden">
        {/* Background orbs */}
        <div className="absolute top-20 left-1/4 w-64 h-64 rounded-full opacity-5 pointer-events-none"
          style={{ background: 'radial-gradient(circle, #00d4ff, transparent)' }} />
        <div className="absolute top-40 right-1/4 w-48 h-48 rounded-full opacity-5 pointer-events-none"
          style={{ background: 'radial-gradient(circle, #8b5cf6, transparent)' }} />

        <div className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-bg-border text-xs text-slate-400 mb-6"
            style={{ background: 'rgba(0,212,255,0.04)' }}>
            <span className="w-1.5 h-1.5 rounded-full bg-brand-green animate-pulse" />
            Built for FAANG placement prep
          </div>

          <h1 className="text-5xl md:text-7xl font-black text-white leading-tight mb-4 tracking-tight">
            AI Daily<br />
            <span className="gradient-text">Coding Challenge</span>
          </h1>

          <p className="text-lg text-slate-400 mb-10 max-w-lg mx-auto leading-relaxed">
            Master coding interviews with daily practice, AI hints, and structured learning — all in one platform.
          </p>

          <div className="flex items-center justify-center gap-4 flex-wrap">
            <button onClick={() => navigate('/login')} className="btn-primary px-8 py-3 text-sm">
              Get Started — It's Free →
            </button>
            <button
              onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
              className="btn-ghost px-6 py-3 text-sm">
              View Features
            </button>
          </div>
        </div>

        {/* Stats strip */}
        <div className={`flex justify-center gap-12 mt-16 transition-all duration-700 delay-300 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {STATS.map(s => (
            <div key={s.label} className="text-center">
              <div className="text-2xl font-black gradient-text">{s.value}</div>
              <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Dashboard preview mockup */}
      <section className="px-6 pb-16">
        <div className="max-w-4xl mx-auto">
          <div className="rounded-2xl border border-bg-border overflow-hidden shadow-2xl"
            style={{ background: '#0d1526', boxShadow: '0 20px 80px rgba(0,212,255,0.06)' }}>
            {/* Mock top bar */}
            <div className="flex items-center gap-2 px-4 py-3 border-b border-bg-border bg-bg-card">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
              <div className="flex-1 mx-4 h-5 rounded-md bg-bg-hover" />
            </div>
            {/* Mock dashboard grid */}
            <div className="p-6 grid grid-cols-4 gap-3">
              {[
                { label: 'Streak', val: '7 🔥', color: '#f59e0b' },
                { label: 'Solved', val: '42', color: '#00d4ff' },
                { label: "Today's", val: '2/3', color: '#10b981' },
                { label: 'Score', val: '840', color: '#8b5cf6' },
              ].map(c => (
                <div key={c.label} className="rounded-xl p-3 border border-bg-border bg-bg-base">
                  <div className="text-lg font-bold" style={{ color: c.color }}>{c.val}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{c.label}</div>
                </div>
              ))}
              <div className="col-span-2 rounded-xl p-3 border border-bg-border bg-bg-base h-20 flex flex-col justify-end gap-1">
                <div className="flex items-end gap-1 h-10">
                  {[2,4,1,5,3,6,4].map((h,i) => (
                    <div key={i} className="flex-1 rounded-sm" style={{ height: `${h*12}%`, background: i===5?'#00d4ff':'rgba(0,212,255,0.25)' }} />
                  ))}
                </div>
                <div className="text-xs text-slate-500">Weekly Activity</div>
              </div>
              <div className="col-span-2 rounded-xl p-3 border border-bg-border bg-bg-base h-20">
                <div className="text-xs text-slate-500 mb-2">Today's Challenges</div>
                {['Two Sum', 'LRU Cache', 'Median Arrays'].map((t,i) => (
                  <div key={t} className="flex items-center gap-2 text-xs text-slate-400 py-0.5">
                    <div className="w-1.5 h-1.5 rounded-full"
                      style={{ background: ['#10b981','#f59e0b','#ef4444'][i] }} />
                    {t}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features grid */}
      <section id="features" className="px-6 py-20 max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-black text-white mb-3">Everything you need to crack interviews</h2>
          <p className="text-slate-400">A complete ecosystem for placement preparation</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {FEATURES.map((f, i) => (
            <div key={f.title} className="card hover:-translate-y-1 cursor-default"
              style={{ animationDelay: `${i * 100}ms` }}>
              <div className="text-2xl mb-3">{f.icon}</div>
              <h3 className="font-bold text-white text-sm mb-1.5">{f.title}</h3>
              <p className="text-slate-500 text-xs leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 py-20 text-center">
        <div className="max-w-lg mx-auto card" style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.05), rgba(139,92,246,0.05))' }}>
          <h2 className="text-2xl font-black text-white mb-3">Start your coding journey today</h2>
          <p className="text-slate-400 text-sm mb-6">Join students preparing for their dream companies</p>
          <button onClick={() => navigate('/login')} className="btn-primary px-8 py-3">
            Create Free Account →
          </button>
        </div>
      </section>
    </div>
  )
}
