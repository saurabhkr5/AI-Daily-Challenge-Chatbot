// pages/Dashboard.jsx — Main dashboard with stats, charts, and daily challenge preview
import { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { getUser } from '../utils/localStorage.js'
import { fetchDailyChallenges } from '../utils/mockAPI.js'
import { WeeklyChart, DifficultyChart } from '../components/ProgressChart.jsx'
import ChallengeCard from '../components/ChallengeCard.jsx'

// Motivational quotes — rotate daily
const QUOTES = [
  { text: "Every expert was once a beginner.", author: "Helen Hayes" },
  { text: "Code is like humor. When you have to explain it, it's bad.", author: "Cory House" },
  { text: "First, solve the problem. Then, write the code.", author: "John Johnson" },
  { text: "The best error message is the one that never shows up.", author: "Thomas Fuchs" },
  { text: "Talk is cheap. Show me the code.", author: "Linus Torvalds" },
  { text: "Programs must be written for people to read.", author: "Harold Abelson" },
  { text: "Simplicity is the soul of efficiency.", author: "Austin Freeman" },
]

function StatCard({ icon, label, value, sub, accent }) {
  return (
    <div className="stat-card" style={{ '--accent-color': accent }}>
      <div className="flex items-start justify-between mb-3">
        <span className="text-xl">{icon}</span>
        <div className="w-1.5 h-1.5 rounded-full animate-pulse-slow" style={{ background: accent }} />
      </div>
      <div className="text-2xl font-black text-white mb-1">{value}</div>
      <div className="text-xs font-semibold text-slate-400">{label}</div>
      {sub && <div className="text-xs text-slate-600 mt-0.5">{sub}</div>}
    </div>
  )
}

export default function Dashboard() {
  const [user, setUser] = useState(getUser())
  const [challenges, setChallenges] = useState([])
  const [loadingChallenges, setLoadingChallenges] = useState(true)
  const navigate = useNavigate()

  const today = new Date().getDay()
  const quote = QUOTES[new Date().getDate() % QUOTES.length]

  // Count solved by difficulty from solved problems
  const dsaData = JSON.parse(localStorage.getItem('cc_dsa_progress') || '{}')
  const dsaCount = Object.keys(dsaData).length

  // Categorize solved by difficulty (approximation based on problem IDs)
  const easyCount = user?.solvedProblems?.filter(id =>
    ['two-sum','palindrome','fizzbuzz','reverse-string','climbing-stairs','max-depth-tree','contains-duplicate','best-time-stocks','merge-sorted','single-number'].includes(id)
  ).length || 0
  const hardCount = user?.solvedProblems?.filter(id =>
    ['median-arrays','trapping-rain','word-break-ii','serialize-tree','sliding-window-max'].includes(id)
  ).length || 0
  const medCount = (user?.totalSolved || 0) - easyCount - hardCount

  // Load today's challenges
  useEffect(() => {
    setLoadingChallenges(true)
    fetchDailyChallenges().then(({ questions }) => {
      setChallenges(questions)
      setLoadingChallenges(false)
    })
  }, [])

  // Refresh user stats when a challenge is solved
  const refreshUser = useCallback(() => {
    setUser(getUser())
  }, [])

  const todaySolved = challenges.filter(q => user?.solvedProblems?.includes(q.id)).length

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Page header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black text-white">
            Hey, {user?.username} 👋
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            {todaySolved === 3
              ? "🎉 You've completed all today's challenges!"
              : `${3 - todaySolved} challenge${3 - todaySolved !== 1 ? 's' : ''} remaining today`}
          </p>
        </div>
        <div className="text-right">
          <div className="text-xs text-slate-500">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </div>
        </div>
      </div>

      {/* Quote of the day */}
      <div className="card py-4 px-5 flex items-center gap-4"
        style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.04), rgba(139,92,246,0.04))', borderColor: 'rgba(0,212,255,0.15)' }}>
        <span className="text-2xl flex-shrink-0">💬</span>
        <div>
          <p className="text-sm text-slate-200 italic">"{quote.text}"</p>
          <p className="text-xs text-slate-500 mt-0.5">— {quote.author}</p>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon="🔥" label="Day Streak" value={user?.streak || 0}
          sub="Keep it going!" accent="#f59e0b" />
        <StatCard icon="✅" label="Total Solved" value={user?.totalSolved || 0}
          sub={`${dsaCount} from DSA sheet`} accent="#00d4ff" />
        <StatCard icon="🎯" label="Today's Progress" value={`${todaySolved}/3`}
          sub={todaySolved === 3 ? 'All done! 🎉' : 'Challenges left'} accent="#10b981" />
        <StatCard icon="🏆" label="DSA Sheet" value={`${dsaCount}/75`}
          sub={`${Math.round(dsaCount/75*100)}% complete`} accent="#8b5cf6" />
      </div>

      {/* Charts row */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white">Weekly Activity</h3>
            <span className="text-xs text-slate-500">Problems solved per day</span>
          </div>
          <WeeklyChart data={user?.weeklyActivity} />
        </div>
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white">Difficulty Distribution</h3>
            <span className="text-xs text-slate-500">By difficulty level</span>
          </div>
          <DifficultyChart
            easy={easyCount}
            medium={Math.max(0, medCount)}
            hard={hardCount}
          />
        </div>
      </div>

      {/* Daily challenges section */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-white">📅 Today's Challenges</h2>
          <button onClick={() => navigate('/app/challenge')}
            className="text-xs text-brand-cyan hover:text-white transition-colors">
            View all →
          </button>
        </div>

        {loadingChallenges ? (
          <div className="grid gap-3">
            {[1,2,3].map(i => (
              <div key={i} className="card h-20 animate-pulse">
                <div className="h-3 w-1/2 bg-bg-hover rounded" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid gap-3">
            {challenges.map(q => (
              <ChallengeCard key={q.id} question={q} onSolved={refreshUser} />
            ))}
          </div>
        )}
      </div>

      {/* Quick nav cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          { to: '/app/dsa-sheet', icon: '📋', label: 'DSA Sheet', sub: `${dsaCount}/75 done` },
          { to: '/app/learn', icon: '📚', label: 'Learning Hub', sub: '8 CS subjects' },
          { to: '/app/profile', icon: '👤', label: 'Profile', sub: 'View achievements' },
        ].map(({ to, icon, label, sub }) => (
          <button key={to} onClick={() => navigate(to)}
            className="card flex items-center gap-3 text-left hover:-translate-y-0.5 cursor-pointer">
            <span className="text-xl">{icon}</span>
            <div>
              <div className="text-sm font-semibold text-white">{label}</div>
              <div className="text-xs text-slate-500">{sub}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
