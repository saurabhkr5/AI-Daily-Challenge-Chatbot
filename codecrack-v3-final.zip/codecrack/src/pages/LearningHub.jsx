// pages/LearningHub.jsx — Browse all CS subjects and topics with progress
import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import learningContent from '../data/learningContent.json'
import { getLearningProgress } from '../utils/localStorage.js'

export default function LearningHub() {
  const navigate = useNavigate()
  const { subjects } = learningContent
  const [search, setSearch] = useState('')
  const progress = getLearningProgress()

  // Total stats
  const totalTopics = subjects.reduce((s, sub) => s + sub.topics.length, 0)
  const totalRead   = subjects.reduce((s, sub) => s + sub.topics.filter(t => progress[t.id]).length, 0)

  // Filter subjects/topics by search
  const filtered = subjects.map(sub => ({
    ...sub,
    topics: search
      ? sub.topics.filter(t =>
          t.title.toLowerCase().includes(search.toLowerCase()) ||
          t.interviewQuestions?.some(q => q.toLowerCase().includes(search.toLowerCase()))
        )
      : sub.topics,
  })).filter(sub => !search || sub.topics.length > 0)

  const studyPath = [
    { phase: '1', title: 'Core DSA', subjects: ['dsa', 'algorithms'], color: '#00d4ff', weeks: '4 weeks' },
    { phase: '2', title: 'CS Fundamentals', subjects: ['dbms', 'os', 'cn'], color: '#8b5cf6', weeks: '3 weeks' },
    { phase: '3', title: 'Software Engineering', subjects: ['oop', 'java', 'systemdesign'], color: '#10b981', weeks: '3 weeks' },
    { phase: '4', title: 'Frontend + Aptitude', subjects: ['react', 'aptitude', 'sql', 'competitive'], color: '#f59e0b', weeks: '2 weeks' },
  ]

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-black text-white mb-1">Learning Hub</h1>
            <p className="text-slate-400 text-sm">
              {totalTopics} topics across {subjects.length} subjects — company-tagged interview questions included
            </p>
          </div>
          {/* Overall progress */}
          <div className="card px-5 py-3 flex items-center gap-4">
            <div className="text-center">
              <div className="text-xl font-black text-white">{totalRead}</div>
              <div className="text-xs text-slate-500">read</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">Overall Progress</div>
              <div className="progress-bar w-32">
                <div className="progress-fill" style={{ width: `${(totalRead/totalTopics)*100}%` }} />
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{Math.round(totalRead/totalTopics*100)}% complete</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="mb-6">
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search topics, concepts, or company questions..."
          className="w-full bg-bg-card border border-bg-border rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-brand-cyan/50 transition-colors"
        />
      </div>

      {/* Study Roadmap */}
      {!search && (
        <div className="mb-7">
          <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">📍 Recommended Study Path</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {studyPath.map(phase => {
              const phaseTopics = subjects
                .filter(s => phase.subjects.includes(s.id))
                .flatMap(s => s.topics)
              const phaseRead = phaseTopics.filter(t => progress[t.id]).length
              return (
                <div key={phase.phase} className="card p-3 border"
                  style={{ borderColor: `${phase.color}30`, background: `${phase.color}08` }}>
                  <div className="text-xs font-black mb-1" style={{ color: phase.color }}>
                    Phase {phase.phase} · {phase.weeks}
                  </div>
                  <div className="text-sm font-bold text-white mb-2">{phase.title}</div>
                  <div className="progress-bar h-1.5 mb-1">
                    <div className="progress-fill" style={{ width: `${(phaseRead/phaseTopics.length)*100}%`, background: phase.color }} />
                  </div>
                  <div className="text-xs text-slate-500">{phaseRead}/{phaseTopics.length} topics</div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Subjects grid */}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
        {filtered.map(subject => {
          const subjectRead = subject.topics.filter(t => progress[t.id]).length
          const pct = subject.topics.length > 0 ? Math.round(subjectRead / subject.topics.length * 100) : 0
          return (
            <div key={subject.id}
              className="card hover:-translate-y-1 transition-all duration-300 group cursor-pointer"
              onClick={() => navigate(`/app/learn/${subject.id}/${subject.topics[0]?.id}`)}>
              {/* Subject header */}
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                  style={{ background: `${subject.color}15`, border: `1px solid ${subject.color}30` }}>
                  {subject.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <h2 className="font-bold text-white text-sm">{subject.title}</h2>
                  <div className="text-xs text-slate-500">{subject.topics.length} topics</div>
                </div>
                {pct === 100 ? (
                  <span className="text-brand-green text-sm">✓</span>
                ) : pct > 0 ? (
                  <span className="text-xs text-slate-500">{pct}%</span>
                ) : (
                  <span className="text-slate-600 text-sm group-hover:text-white transition-colors">→</span>
                )}
              </div>

              {/* Progress bar */}
              {pct > 0 && (
                <div className="progress-bar h-1 mb-3">
                  <div className="progress-fill" style={{ width: `${pct}%`, background: subject.color }} />
                </div>
              )}

              {/* Topics list */}
              <div className="space-y-1">
                {subject.topics.slice(0, 5).map(topic => (
                  <div key={topic.id}
                    onClick={e => { e.stopPropagation(); navigate(`/app/learn/${subject.id}/${topic.id}`) }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-bg-hover transition-colors cursor-pointer group/topic">
                    <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                      progress[topic.id] ? 'bg-brand-green' : 'bg-slate-700'
                    }`} />
                    <span className="text-xs text-slate-400 group-hover/topic:text-white transition-colors flex-1">
                      {topic.title}
                    </span>
                    {topic.interviewQuestions?.length > 0 && (
                      <span className="text-xs text-slate-600">{topic.interviewQuestions.length}Q</span>
                    )}
                  </div>
                ))}
                {subject.topics.length > 5 && (
                  <div className="text-xs text-slate-600 px-2 py-1">
                    +{subject.topics.length - 5} more topics
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Study Strategy */}
      {!search && (
        <div className="mt-7 card py-4"
          style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.04), rgba(59,130,246,0.04))' }}>
          <div className="flex items-start gap-3">
            <span className="text-xl">🎓</span>
            <div>
              <h3 className="text-sm font-bold text-white mb-1">Placement Preparation Strategy</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                <strong className="text-white">Product Companies (Google, Meta, Amazon):</strong> Focus heavily on DSA + Algorithms + System Design.{' '}
                <strong className="text-white">Service Companies (TCS, Infosys, Wipro):</strong> DBMS + OS + OOP + Aptitude are equally important.{' '}
                <strong className="text-white">Fintech (Goldman Sachs, Paytm):</strong> Add SQL + Network Security.{' '}
                Each topic shows the number of interview questions (Q) from top companies.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
