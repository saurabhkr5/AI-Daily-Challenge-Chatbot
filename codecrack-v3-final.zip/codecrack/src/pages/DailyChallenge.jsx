// pages/DailyChallenge.jsx
// Shows today's 3 coding challenges (Easy / Medium / Hard).
// Questions are cached in localStorage by date. A Refresh button lets the
// user generate a fresh random set without waiting until tomorrow.

import { useState, useEffect, useCallback } from 'react'
import { fetchDailyChallenges, refreshDailyQuestions } from '../utils/mockAPI.js'
import { getUser } from '../utils/localStorage.js'
import ChallengeCard from '../components/ChallengeCard.jsx'

const DIFF_INFO = {
  Easy:   { color: '#10b981', icon: '🟢', desc: 'Great for warm-up. Focus on fundamentals.' },
  Medium: { color: '#f59e0b', icon: '🟡', desc: 'Core interview difficulty. Think carefully.' },
  Hard:   { color: '#ef4444', icon: '🔴', desc: 'Advanced problems. Take your time.' },
}

export default function DailyChallenge() {
  const [challenges, setChallenges] = useState([])
  const [loading, setLoading]       = useState(true)
  const [refreshing, setRefreshing] = useState(false)  // separate spinner for refresh
  const [fromCache, setFromCache]   = useState(false)
  const [user, setUser]             = useState(getUser())

  // Load today's questions on mount
  useEffect(() => {
    loadQuestions()
  }, [])

  // Fetch (or read from cache) today's questions
  async function loadQuestions() {
    setLoading(true)
    const { questions, fromCache: cached } = await fetchDailyChallenges()
    setChallenges(questions)
    setFromCache(cached)
    setLoading(false)
  }

  // ── REFRESH HANDLER ────────────────────────────────────────────────────────
  // Step 1: Remove today's cached questions from localStorage.
  // Step 2: Call refreshDailyQuestions() which generates a new random set.
  // Step 3: Update state so the UI re-renders with the new questions.
  async function handleRefresh() {
    setRefreshing(true)
    const { questions } = await refreshDailyQuestions()
    setChallenges(questions)
    setFromCache(false)
    setRefreshing(false)
  }
  // ──────────────────────────────────────────────────────────────────────────

  // Re-read user from storage when a challenge is solved (so progress bar updates)
  const refreshUser = useCallback(() => {
    setUser(getUser())
  }, [])

  const solvedToday = challenges.filter(q => user?.solvedProblems?.includes(q.id)).length

  return (
    <div className="p-6 max-w-3xl mx-auto">

      {/* ── Page Header ─────────────────────────────────────────────────── */}
      <div className="mb-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-2xl font-black text-white">Daily Challenges</h1>
              {/* Show "💾 cached" badge when questions came from localStorage */}
              {fromCache && !loading && (
                <span className="text-xs px-2 py-0.5 rounded-full text-slate-500 border border-bg-border font-mono">
                  💾 cached
                </span>
              )}
            </div>
            <p className="text-slate-400 text-sm">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })} •{' '}
              {solvedToday === 3
                ? '🎉 All challenges completed!'
                : `${solvedToday}/3 completed`}
            </p>
          </div>

          {/* ── Refresh Button ─────────────────────────────────────────── */}
          {/* Deletes today's cache and generates a new random question set */}
          <button
            onClick={handleRefresh}
            disabled={refreshing || loading}
            className="flex items-center gap-2 text-xs px-4 py-2 rounded-xl border border-bg-border text-slate-400
                       hover:text-white hover:border-slate-500 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {/* Spinning icon while refreshing */}
            <span className={refreshing ? 'animate-spin inline-block' : 'inline-block'}>🔄</span>
            {refreshing ? 'Refreshing...' : 'Refresh Questions'}
          </button>
          {/* ─────────────────────────────────────────────────────────────── */}
        </div>
      </div>

      {/* ── Progress Card ───────────────────────────────────────────────── */}
      <div className="card mb-6 py-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span>Today's Progress</span>
          <span className="font-bold text-white">{solvedToday}/3</span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${(solvedToday / 3) * 100}%` }} />
        </div>
        {solvedToday === 3 && (
          <div className="mt-3 text-center text-sm text-brand-green font-semibold">
            🏆 Congratulations! All done for today. Come back tomorrow!
          </div>
        )}
      </div>

      {/* ── Challenge Cards ─────────────────────────────────────────────── */}
      {loading || refreshing ? (
        // Skeleton loading state
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="card h-28 animate-pulse">
              <div className="space-y-3">
                <div className="h-3 w-1/3 bg-bg-hover rounded" />
                <div className="h-2 w-2/3 bg-bg-hover rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {challenges.map((q) => {
            const info = DIFF_INFO[q.difficulty] || DIFF_INFO.Easy
            return (
              <div key={q.id}>
                {/* Difficulty label above each card */}
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm">{info.icon}</span>
                  <h3 className="text-sm font-bold" style={{ color: info.color }}>
                    {q.difficulty} Challenge
                  </h3>
                  <span className="text-xs text-slate-600">— {info.desc}</span>
                </div>
                <ChallengeCard question={q} onSolved={refreshUser} />
              </div>
            )
          })}
        </div>
      )}

      {/* ── Tips Section ────────────────────────────────────────────────── */}
      <div className="mt-8 card"
        style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.04), rgba(139,92,246,0.04))' }}>
        <h3 className="text-sm font-bold text-white mb-3">💡 Problem-Solving Tips</h3>
        <div className="space-y-2">
          {[
            'Understand the problem fully before coding. Read examples carefully.',
            'Start with a brute-force solution, then optimise.',
            'Consider edge cases: empty input, single element, negative numbers.',
            'Explain your approach out loud — practice interview communication.',
            'Use the AI chatbot (bottom-right) if you get stuck!',
          ].map((tip, i) => (
            <div key={i} className="flex items-start gap-2 text-xs text-slate-400">
              <span className="text-brand-cyan font-bold mt-0.5">{i + 1}.</span>
              <span>{tip}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  )
}
