// pages/DSASheet.jsx — Top 50 DSA Sheet with progress tracking
import { useState, useCallback } from 'react'
import { getDSAProgress, toggleDSASolved } from '../utils/localStorage.js'
import dsaQuestions from '../data/dsaQuestions.json'

const CATEGORIES = [
  'Arrays', 'Strings', 'Linked List', 'Stack', 'Queue',
  'Trees', 'Graph', 'Dynamic Programming',
  'Binary Search', 'Heap', 'Two Pointers', 'Sliding Window', 'Tries', 'Backtracking',
]

const DIFF_CONFIG = {
  Easy:   { class: 'badge-easy',   dot: 'bg-brand-green' },
  Medium: { class: 'badge-medium', dot: 'bg-brand-yellow' },
  Hard:   { class: 'badge-hard',   dot: 'bg-brand-red' },
}

export default function DSASheet() {
  const [progress, setProgress] = useState(getDSAProgress())
  const [activeCategory, setActiveCategory] = useState('All')
  const [search, setSearch] = useState('')

  // Get counts per category
  const categoryMap = {}
  CATEGORIES.forEach(cat => {
    const qs = dsaQuestions.filter(q => q.category === cat)
    const done = qs.filter(q => progress[q.id]).length
    categoryMap[cat] = { total: qs.length, done }
  })

  const totalDone = Object.keys(progress).length
  const total = dsaQuestions.length

  // Filter questions
  const filtered = dsaQuestions.filter(q => {
    const matchCat = activeCategory === 'All' || q.category === activeCategory
    const matchSearch = !search || q.title.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchSearch
  })

  const handleToggle = useCallback((id) => {
    const updated = toggleDSASolved(id)
    setProgress({ ...updated })
  }, [])

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-black text-white mb-1">DSA Question Sheet</h1>
        <p className="text-slate-400 text-sm">
          75 essential problems across 14 categories for placement preparation. Track your progress below.
        </p>
      </div>

      {/* Overall progress */}
      <div className="card mb-6">
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-3xl font-black gradient-text">{totalDone}</span>
            <span className="text-slate-500 text-sm"> / {total} solved</span>
          </div>
          <div className="text-right">
            <div className="text-xl font-bold text-white">{Math.round(totalDone/total*100)}%</div>
            <div className="text-xs text-slate-500">of {total} total</div>
          </div>
        </div>
        <div className="progress-bar h-2.5">
          <div className="progress-fill" style={{ width: `${(totalDone/total)*100}%` }} />
        </div>
        {/* Category mini-stats — first 8 */}
        <div className="mt-4 grid grid-cols-4 gap-2">
          {CATEGORIES.slice(0,8).map(cat => (
            <div key={cat} className="text-center">
              <div className="text-sm font-bold text-white">{categoryMap[cat].done}/{categoryMap[cat].total}</div>
              <div className="text-xs text-slate-600 truncate">{cat}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-4">
        {/* Category sidebar */}
        <div className="w-44 flex-shrink-0">
          <div className="card p-3 space-y-1">
            <button
              onClick={() => setActiveCategory('All')}
              className={`topic-item w-full ${activeCategory === 'All' ? 'active' : ''}`}
            >
              <span className="text-sm">📋</span>
              <span>All ({total})</span>
            </button>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`topic-item w-full justify-between ${activeCategory === cat ? 'active' : ''}`}
              >
                <span className="truncate text-xs">{cat}</span>
                <span className="text-xs ml-1 flex-shrink-0 opacity-60">
                  {categoryMap[cat].done}/{categoryMap[cat].total}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Questions list */}
        <div className="flex-1 min-w-0">
          {/* Search */}
          <div className="mb-3">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search problems..."
              className="w-full bg-bg-card border border-bg-border rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-brand-cyan/40 transition-colors"
            />
          </div>

          {/* Problem rows */}
          <div className="space-y-2">
            {filtered.length === 0 ? (
              <div className="card text-center text-slate-500 text-sm py-8">No problems found</div>
            ) : (
              filtered.map((q, i) => {
                const solved = !!progress[q.id]
                const diff = DIFF_CONFIG[q.difficulty] || DIFF_CONFIG.Easy
                return (
                  <div key={q.id}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition-all duration-200 group ${
                      solved
                        ? 'border-brand-green/20 bg-brand-green/3'
                        : 'border-bg-border bg-bg-card hover:border-slate-600'
                    }`}>
                    {/* Checkbox */}
                    <button
                      onClick={() => handleToggle(q.id)}
                      className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-all duration-200 ${
                        solved
                          ? 'bg-brand-green border-brand-green text-white'
                          : 'border-bg-border hover:border-brand-green/50'
                      }`}
                    >
                      {solved && <span className="text-xs font-bold">✓</span>}
                    </button>

                    {/* Title */}
                    <div className="flex-1 min-w-0">
                      <span className={`text-sm font-medium ${solved ? 'text-slate-500 line-through' : 'text-white'}`}>
                        {q.title}
                      </span>
                      <span className="ml-2 text-xs text-slate-600">{q.category}</span>
                    </div>

                    {/* Difficulty */}
                    <span className={`${diff.class} flex-shrink-0`}>{q.difficulty}</span>

                    {/* Links */}
                    <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <a href={q.lcLink} target="_blank" rel="noopener noreferrer"
                        className="text-xs px-2 py-1 rounded-lg border border-bg-border text-slate-500 hover:text-brand-cyan hover:border-brand-cyan/30 transition-colors">
                        LC
                      </a>
                      <a href={q.gfgLink} target="_blank" rel="noopener noreferrer"
                        className="text-xs px-2 py-1 rounded-lg border border-bg-border text-slate-500 hover:text-brand-green hover:border-brand-green/30 transition-colors">
                        GFG
                      </a>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
