// pages/Login.jsx — Gmail + username login for per-user progress tracking
import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { getUser, createUser, getCurrentGmail } from '../utils/localStorage.js'

export default function Login() {
  const [username, setUsername]   = useState('')
  const [gmail, setGmail]         = useState('')
  const [errors, setErrors]       = useState({})
  const [isReturning, setIsReturning] = useState(false)
  const navigate = useNavigate()

  // If already logged in, redirect
  useEffect(() => {
    if (getCurrentGmail() && getUser()) navigate('/app/dashboard')
  }, [navigate])

  // When gmail changes, check if this user already exists
  function handleGmailBlur() {
    if (!gmail.trim()) return
    const existing = getUser(gmail.trim().toLowerCase())
    if (existing) {
      setIsReturning(true)
      setUsername(existing.username)
    } else {
      setIsReturning(false)
    }
  }

  function validate() {
    const errs = {}
    const name = username.trim()
    const g = gmail.trim().toLowerCase()
    if (!name || name.length < 2) errs.username = 'Name must be at least 2 characters'
    if (!g) errs.gmail = 'Gmail is required'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(g)) errs.gmail = 'Enter a valid email address'
    return errs
  }

  function handleSubmit(e) {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length) { setErrors(errs); return }
    createUser(username.trim(), gmail.trim().toLowerCase())
    navigate('/app/dashboard')
  }

  const features = [
    ['🎯', 'Daily AI-curated challenges'],
    ['📋', '75-question DSA Sheet tracker'],
    ['📚', 'Massive CS learning hub (60+ topics)'],
    ['🤖', 'Gemini AI hints & explanations'],
    ['🔥', 'Per-account streak & achievements'],
    ['👤', 'Progress saved per Gmail — use on any device'],
  ]

  return (
    <div className="min-h-screen bg-bg-base flex bg-mesh">
      {/* Left panel */}
      <div className="hidden lg:flex flex-1 flex-col justify-center items-center p-12 relative overflow-hidden border-r border-bg-border">
        <div className="absolute top-20 left-10 w-40 h-40 rounded-full opacity-10 pointer-events-none"
          style={{ background: 'radial-gradient(circle, #00d4ff, transparent)' }} />
        <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full opacity-10 pointer-events-none"
          style={{ background: 'radial-gradient(circle, #8b5cf6, transparent)' }} />

        <div className="max-w-xs text-center">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black mx-auto mb-6"
            style={{ background: 'linear-gradient(135deg, #00d4ff, #3b82f6)' }}>CC</div>
          <h1 className="text-3xl font-black text-white mb-4 leading-tight">
            Crack Every<br /><span className="gradient-text">Tech Interview</span>
          </h1>
          <p className="text-slate-400 text-sm leading-relaxed">
            AI-powered daily practice, structured DSA prep, and company-specific question banks.
          </p>
          <div className="mt-8 space-y-3 text-left">
            {features.map(([icon, text]) => (
              <div key={text} className="flex items-center gap-3 text-sm text-slate-400">
                <span>{icon}</span><span>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex flex-col justify-center items-center p-8">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2.5 mb-8">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-black"
              style={{ background: 'linear-gradient(135deg, #00d4ff, #3b82f6)' }}>CC</div>
            <span className="font-black text-white text-lg">CodeCrack</span>
          </div>

          {isReturning ? (
            <div className="mb-6 p-3 rounded-xl border border-brand-green/30 bg-brand-green/5 flex items-center gap-2">
              <span>👋</span>
              <div>
                <div className="text-sm font-semibold text-brand-green">Welcome back, {username}!</div>
                <div className="text-xs text-slate-400">Your progress has been restored.</div>
              </div>
            </div>
          ) : (
            <>
              <h2 className="text-2xl font-black text-white mb-1">Get Started 🚀</h2>
              <p className="text-slate-400 text-sm mb-8">Your Gmail identifies your account across devices</p>
            </>
          )}

          <div className="space-y-5">
            {/* Gmail field */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Gmail Address
              </label>
              <input
                type="email"
                value={gmail}
                onChange={e => { setGmail(e.target.value); setErrors(p => ({ ...p, gmail: '' })) }}
                onBlur={handleGmailBlur}
                placeholder="yourname@gmail.com"
                className="w-full bg-bg-card border border-bg-border rounded-xl px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-brand-cyan/50 transition-colors text-sm"
              />
              {errors.gmail && <p className="mt-1.5 text-xs text-red-400">{errors.gmail}</p>}
            </div>

            {/* Username field */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Display Name
              </label>
              <input
                type="text"
                value={username}
                onChange={e => { setUsername(e.target.value); setErrors(p => ({ ...p, username: '' })) }}
                placeholder="e.g. Saurabh"
                maxLength={25}
                className="w-full bg-bg-card border border-bg-border rounded-xl px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-brand-cyan/50 transition-colors text-sm"
              />
              {errors.username && <p className="mt-1.5 text-xs text-red-400">{errors.username}</p>}
            </div>

            <button onClick={handleSubmit} className="btn-primary w-full py-3 text-sm">
              {isReturning ? 'Continue Journey →' : 'Start Coding →'}
            </button>
          </div>

          <p className="mt-5 text-xs text-slate-600 text-center">
            Your Gmail is stored locally only — never sent to any server.
          </p>

          <div className="mt-6 pt-5 border-t border-bg-border">
            <Link to="/" className="text-xs text-slate-500 hover:text-slate-300 transition-colors">
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
