// pages/TopicPage.jsx — Full learning content for a specific topic
// Now includes company-asked interview questions and learning progress tracking
import { useParams, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import learningContent from '../data/learningContent.json'
import { markTopicRead, getLearningProgress } from '../utils/localStorage.js'

const SECTIONS = [
  { id: 'definition',  label: '📖 Definition' },
  { id: 'explanation', label: '🧠 Explanation' },
  { id: 'example',     label: '💻 Code' },
  { id: 'questions',   label: '🎤 Interview Qs' },
]

export default function TopicPage() {
  const { subjectId, topicId } = useParams()
  const navigate = useNavigate()
  const [activeSection, setActiveSection] = useState('definition')
  const [progress, setProgress] = useState(getLearningProgress())

  const subject = learningContent.subjects.find(s => s.id === subjectId)
  const topic   = subject?.topics.find(t => t.id === topicId)

  // Mark topic as read on mount + when topic changes
  useEffect(() => {
    if (topicId) {
      markTopicRead(topicId)
      setProgress(getLearningProgress())
    }
    setActiveSection('definition')
    window.scrollTo(0, 0)
  }, [topicId])

  if (!subject || !topic) {
    return (
      <div className="p-6 text-center">
        <p className="text-slate-400">Topic not found.</p>
        <button onClick={() => navigate('/app/learn')} className="btn-ghost mt-4 text-sm">
          ← Learning Hub
        </button>
      </div>
    )
  }

  const topicIndex = subject.topics.findIndex(t => t.id === topicId)
  const prevTopic  = subject.topics[topicIndex - 1]
  const nextTopic  = subject.topics[topicIndex + 1]

  // Split company questions by company name
  function parseCompanyQuestion(q) {
    const match = q.match(/^([^:]+):\s*(.+)$/)
    return match ? { company: match[1].trim(), question: match[2].trim() } : { company: '', question: q }
  }

  const companyColors = {
    Google: '#4285F4', Amazon: '#FF9900', Microsoft: '#00A4EF', Meta: '#0082FB',
    'Goldman Sachs': '#6495ED', Adobe: '#FF0000', Uber: '#000000', Netflix: '#E50914',
    Flipkart: '#2874F0', Paytm: '#00BAF2', Samsung: '#1428A0', Oracle: '#F80000',
    TCS: '#720018', Infosys: '#007CC3', Wipro: '#341C5C', Cognizant: '#1A4CA1',
    Accenture: '#A100FF', HCL: '#EF3B2C', Capgemini: '#003893', Cisco: '#1BA0D7',
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      <div className="flex gap-5">

        {/* ── Sidebar ─────────────────────────────────────────────────────── */}
        <div className="w-48 flex-shrink-0 hidden md:block">
          <button onClick={() => navigate('/app/learn')}
            className="flex items-center gap-2 text-xs text-slate-500 hover:text-white transition-colors mb-4">
            ← Learning Hub
          </button>

          <div className="card p-3 mb-3">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-lg">{subject.icon}</span>
              <span className="text-sm font-bold text-white">{subject.title}</span>
            </div>
            <div className="space-y-0.5">
              {subject.topics.map(t => (
                <button key={t.id}
                  onClick={() => navigate(`/app/learn/${subject.id}/${t.id}`)}
                  className={`topic-item w-full text-left ${t.id === topicId ? 'active' : ''}`}>
                  <div className="flex items-center gap-2">
                    {/* Green dot if topic has been read */}
                    <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                      progress[t.id] ? 'bg-brand-green' : 'bg-slate-700'
                    }`} />
                    <span className="text-xs leading-tight">{t.title}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Progress in this subject */}
            <div className="mt-3 pt-3 border-t border-bg-border">
              <div className="flex justify-between text-xs text-slate-500 mb-1">
                <span>Progress</span>
                <span>{subject.topics.filter(t => progress[t.id]).length}/{subject.topics.length}</span>
              </div>
              <div className="progress-bar h-1.5">
                <div className="progress-fill"
                  style={{ width: `${subject.topics.filter(t => progress[t.id]).length / subject.topics.length * 100}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* ── Main Content ─────────────────────────────────────────────────── */}
        <div className="flex-1 min-w-0">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
            <button onClick={() => navigate('/app/learn')} className="hover:text-white transition-colors">
              Learning Hub
            </button>
            <span>/</span>
            <span style={{ color: subject.color }}>{subject.title}</span>
            <span>/</span>
            <span className="text-white">{topic.title}</span>
          </div>

          <h1 className="text-2xl font-black text-white mb-4">{topic.title}</h1>

          {/* Section tabs */}
          <div className="flex gap-1 mb-5 bg-bg-card rounded-xl p-1 border border-bg-border overflow-x-auto">
            {SECTIONS.map(s => (
              <button key={s.id} onClick={() => setActiveSection(s.id)}
                className={`px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all duration-200 ${
                  activeSection === s.id
                    ? 'bg-bg-hover text-white shadow'
                    : 'text-slate-500 hover:text-slate-300'
                }`}>
                {s.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="card">

            {/* Definition */}
            {activeSection === 'definition' && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-1 h-8 rounded-full" style={{ background: subject.color }} />
                  <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Definition</h2>
                </div>
                <p className="text-white text-base leading-relaxed font-medium">{topic.definition}</p>
              </div>
            )}

            {/* Explanation */}
            {activeSection === 'explanation' && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-1 h-8 rounded-full" style={{ background: subject.color }} />
                  <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Detailed Explanation</h2>
                </div>
                <div className="space-y-2">
                  {topic.explanation.split('\n').filter(Boolean).map((line, i) => {
                    const isBold = /^[A-Z0-9].*[:-]/.test(line.trim()) || /^\d+\./.test(line.trim())
                    return (
                      <p key={i} className={`text-sm leading-relaxed ${
                        isBold ? 'text-white font-semibold mt-3' : 'text-slate-300'
                      }`}>
                        {line}
                      </p>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Code Example */}
            {activeSection === 'example' && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-1 h-8 rounded-full" style={{ background: subject.color }} />
                  <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Code Example</h2>
                </div>
                <div className="rounded-xl overflow-hidden border border-bg-border">
                  <div className="flex items-center gap-2 px-4 py-2.5 bg-bg-hover border-b border-bg-border">
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
                      <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
                    </div>
                    <span className="text-xs text-slate-500 font-mono ml-2">example.java</span>
                  </div>
                  <pre className="p-5 overflow-x-auto text-sm font-mono text-brand-green leading-relaxed"
                    style={{ background: '#060a12' }}>
                    {topic.example}
                  </pre>
                </div>
              </div>
            )}

            {/* Interview Questions — grouped by company */}
            {activeSection === 'questions' && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-1 h-8 rounded-full" style={{ background: subject.color }} />
                  <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">
                    Company-Asked Interview Questions
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mb-4">
                  {topic.interviewQuestions.length} questions asked across top tech & service companies
                </p>

                <div className="space-y-2.5">
                  {topic.interviewQuestions.map((q, i) => {
                    const { company, question } = parseCompanyQuestion(q)
                    const color = companyColors[company] || '#64748b'
                    return (
                      <div key={i}
                        className="flex gap-3 p-3 rounded-xl border border-bg-border hover:border-slate-600 transition-colors"
                        style={{ background: 'rgba(255,255,255,0.02)' }}>
                        <div className="flex-shrink-0 text-center">
                          <div className="text-xs font-black w-6 text-slate-600">Q{i+1}</div>
                        </div>
                        <div className="flex-1 min-w-0">
                          {company && (
                            <span className="inline-block text-xs font-bold px-2 py-0.5 rounded-full mr-2 mb-1"
                              style={{ background: `${color}20`, color: color, border: `1px solid ${color}40` }}>
                              {company}
                            </span>
                          )}
                          <p className="text-sm text-white leading-relaxed">{question}</p>
                        </div>
                      </div>
                    )
                  })}
                </div>

                <div className="mt-5 p-3 rounded-xl border border-bg-border text-xs text-slate-500"
                  style={{ background: 'rgba(0,212,255,0.03)' }}>
                  💡 <strong className="text-slate-400">Interview Tip:</strong> Practice answering these
                  out loud. Use STAR method for behavioural questions. For technical ones, think
                  through edge cases and time/space complexity before answering.
                </div>
              </div>
            )}
          </div>

          {/* Prev/Next navigation */}
          <div className="flex justify-between mt-4 gap-3">
            {prevTopic ? (
              <button onClick={() => navigate(`/app/learn/${subject.id}/${prevTopic.id}`)}
                className="btn-ghost text-xs py-2 flex items-center gap-1.5">
                ← {prevTopic.title}
              </button>
            ) : <div />}
            {nextTopic ? (
              <button onClick={() => navigate(`/app/learn/${subject.id}/${nextTopic.id}`)}
                className="btn-primary text-xs py-2 flex items-center gap-1.5">
                {nextTopic.title} →
              </button>
            ) : (
              <button onClick={() => navigate('/app/learn')}
                className="btn-primary text-xs py-2">
                Back to Hub ✓
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
